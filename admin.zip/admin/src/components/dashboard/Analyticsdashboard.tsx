import React, { useEffect, useMemo, useState } from "react";
import {
    Eye,
    FileText,
    Users,
    Timer,
    Download,
    ChevronDown,
    MoreVertical,
    ArrowRight,
    Monitor,
    Smartphone,
    Tablet,
    Image as ImageIcon,
    TrendingUp,
    TrendingDown,
} from "lucide-react";
import {
    ResponsiveContainer,
    AreaChart,
    Area,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
} from "recharts";

// ---------------------------------------------------------------------------
// API base — point this at your Express server (mounted at "/admin").
// ---------------------------------------------------------------------------
const API_BASE = "/admin";

// Endpoints that actually exist on the backend:
//   GET  /admin/analytics        -> { success, analytics: { totalViews, totalBlogs } }
//   GET  /admin/analytics/blogs  -> { success, blogs: [{ title, slug, views, createdAt }] }
async function fetchAnalytics() {
    const res = await fetch(`${API_BASE}/analytics`, { credentials: "include" });
    if (!res.ok) throw new Error("Failed to load analytics");
    const data = await res.json();
    return data.analytics;
}

async function fetchBlogAnalytics() {
    const res = await fetch(`${API_BASE}/analytics/blogs`, { credentials: "include" });
    if (!res.ok) throw new Error("Failed to load blog analytics");
    const data = await res.json();
    return data.blogs ?? [];
}

// ---------------------------------------------------------------------------
// The four fields below have no backend support (no route, no schema field):
// unique visitors, avg. read time, the % deltas, the 7-day view series, and
// the device breakdown. They're left as clearly-labeled placeholders so the
// UI matches the screenshot — swap them for real data once those endpoints
// / fields exist.
// ---------------------------------------------------------------------------
const PLACEHOLDER_SERIES = [
    { day: "Mon", views: 27000 },
    { day: "Tue", views: 30000 },
    { day: "Wed", views: 53000 },
    { day: "Thu", views: 49000 },
    { day: "Fri", views: 71000 },
    { day: "Sat", views: 65000 },
    { day: "Sun", views: 84000 },
]; // TODO: backend — needs a time-bucketed views endpoint

const PLACEHOLDER_DEVICES = [
    { label: "Desktop", pct: 65, icon: Monitor },
    { label: "Mobile", pct: 28, icon: Smartphone },
    { label: "Tablet", pct: 7, icon: Tablet },
]; // TODO: backend — needs device/user-agent tracking on views

const PLACEHOLDER_DELTAS = {
    totalViews: 12.5,
    totalBlogs: 3.2,
    uniqueVisitors: -1.1,
    avgReadTime: 5.0,
}; // TODO: backend — needs a previous-period comparison in getAnalytics

function formatCompact(n) {
    if (n == null) return "—";
    if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
    if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
    return `${n}`;
}

function formatDate(d) {
    if (!d) return "—";
    return new Date(d).toLocaleDateString("en-US", {
        month: "short",
        day: "2-digit",
        year: "numeric",
    });
}

function DeltaPill({ value }) {
    const positive = value >= 0;
    const Icon = positive ? TrendingUp : TrendingDown;
    return (
        <span
            className={
                "inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold " +
                (positive ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-500")
            }
        >
            <Icon className="h-3.5 w-3.5" strokeWidth={2.5} />
            {positive ? "+" : ""}
            {value.toFixed(1)}%
        </span>
    );
}

function StatCard({ icon: Icon, label, value, delta, loading }) {
    return (
        <div className="rounded-2xl border border-gray-200 bg-white p-6">
            <div className="flex items-center justify-between">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-50">
                    <Icon className="h-5 w-5 text-indigo-600" strokeWidth={2} />
                </div>
                <DeltaPill value={delta} />
            </div>
            <p className="mt-4 text-sm text-gray-500">{label}</p>
            <p className="mt-1 text-3xl font-extrabold tracking-tight text-gray-900">
                {loading ? (
                    <span className="inline-block h-8 w-20 animate-pulse rounded bg-gray-100 align-middle" />
                ) : (
                    value
                )}
            </p>
        </div>
    );
}

function CustomTooltip({ active, payload, label }) {
    if (!active || !payload?.length) return null;
    return (
        <div className="rounded-lg border border-gray-100 bg-white px-3 py-2 shadow-lg">
            <p className="text-xs font-medium text-gray-400">{label}</p>
            <p className="text-sm font-bold text-gray-900">
                {payload[0].value.toLocaleString()} views
            </p>
        </div>
    );
}

export default function AnalyticsDashboard() {
    const [analytics, setAnalytics] = useState(null);
    const [blogs, setBlogs] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [range, setRange] = useState("Last 7 Days");

    useEffect(() => {
        let cancelled = false;

        async function load() {
            setLoading(true);
            setError(null);
            try {
                const [a, b] = await Promise.all([fetchAnalytics(), fetchBlogAnalytics()]);
                if (!cancelled) {
                    setAnalytics(a);
                    setBlogs(b);
                }
            } catch (err) {
                if (!cancelled) setError(err.message || "Something went wrong");
            } finally {
                if (!cancelled) setLoading(false);
            }
        }

        load();
        return () => {
            cancelled = true;
        };
    }, []);

    const topBlogs = useMemo(() => blogs.slice(0, 4), [blogs]);

    return (
        <div className="min-h-screen w-full bg-gray-50 p-6 sm:p-8">
            <div className="mx-auto max-w-6xl">
                {/* Header */}
                <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                        <h1 className="text-3xl font-extrabold tracking-tight text-gray-900">
                            Analytics Overview
                        </h1>
                        <p className="mt-1 text-sm text-gray-500">
                            Real-time performance metrics and content engagement.
                        </p>
                    </div>

                    <div className="flex items-center gap-3">
                        <button
                            type="button"
                            onClick={() =>
                                setRange((r) => (r === "Last 7 Days" ? "Last 30 Days" : "Last 7 Days"))
                            }
                            className="inline-flex items-center gap-2 rounded-xl border border-gray-200 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
                        >
                            {range}
                            <ChevronDown className="h-4 w-4 text-gray-400" />
                        </button>
                        <button
                            type="button"
                            className="inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-500"
                        >
                            <Download className="h-4 w-4" />
                            Export
                        </button>
                    </div>
                </div>

                {error && (
                    <div className="mt-6 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-600">
                        {error}
                    </div>
                )}

                {/* Stat cards */}
                <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
                    <StatCard
                        icon={Eye}
                        label="Total Views"
                        value={formatCompact(analytics?.totalViews)}
                        delta={PLACEHOLDER_DELTAS.totalViews}
                        loading={loading}
                    />
                    <StatCard
                        icon={FileText}
                        label="Total Blogs"
                        value={analytics?.totalBlogs ?? "—"}
                        delta={PLACEHOLDER_DELTAS.totalBlogs}
                        loading={loading}
                    />
                    <StatCard
                        icon={Users}
                        label="Unique Visitors"
                        value={formatCompact(842_000)}
                        delta={PLACEHOLDER_DELTAS.uniqueVisitors}
                        loading={false}
                    />
                    <StatCard
                        icon={Timer}
                        label="Avg. Read Time"
                        value="4m 12s"
                        delta={PLACEHOLDER_DELTAS.avgReadTime}
                        loading={false}
                    />
                </div>

                {/* Chart + device breakdown */}
                <div className="mt-6 grid grid-cols-1 gap-5 lg:grid-cols-3">
                    <div className="rounded-2xl border border-gray-200 bg-white p-6 lg:col-span-2">
                        <div className="flex items-center justify-between">
                            <h2 className="text-lg font-bold text-gray-900">Views over Time</h2>
                            <button
                                type="button"
                                className="rounded-md p-1 text-gray-400 hover:bg-gray-50 hover:text-gray-600"
                            >
                                <MoreVertical className="h-5 w-5" />
                            </button>
                        </div>
                        <div className="mt-4 h-72">
                            <ResponsiveContainer width="100%" height="100%">
                                <AreaChart data={PLACEHOLDER_SERIES} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                                    <defs>
                                        <linearGradient id="viewsFill" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="0%" stopColor="#6366f1" stopOpacity={0.25} />
                                            <stop offset="100%" stopColor="#6366f1" stopOpacity={0} />
                                        </linearGradient>
                                    </defs>
                                    <CartesianGrid vertical={false} stroke="#F1F1F4" />
                                    <XAxis
                                        dataKey="day"
                                        axisLine={false}
                                        tickLine={false}
                                        tick={{ fill: "#9CA3AF", fontSize: 12 }}
                                    />
                                    <YAxis
                                        axisLine={false}
                                        tickLine={false}
                                        tick={{ fill: "#9CA3AF", fontSize: 12 }}
                                        tickFormatter={(v) => (v === 0 ? "0" : `${v / 1000}k`)}
                                        domain={[0, 100000]}
                                    />
                                    <Tooltip content={<CustomTooltip />} />
                                    <Area
                                        type="monotone"
                                        dataKey="views"
                                        stroke="#6366f1"
                                        strokeWidth={3}
                                        fill="url(#viewsFill)"
                                    />
                                </AreaChart>
                            </ResponsiveContainer>
                        </div>
                    </div>

                    <div className="rounded-2xl border border-gray-200 bg-white p-6">
                        <h2 className="text-lg font-bold text-gray-900">Device Breakdown</h2>
                        <div className="mt-8 space-y-6">
                            {PLACEHOLDER_DEVICES.map(({ label, pct, icon: Icon }) => (
                                <div key={label}>
                                    <div className="flex items-center justify-between text-sm">
                                        <span className="flex items-center gap-2 font-medium text-gray-700">
                                            <Icon className="h-4 w-4 text-indigo-500" />
                                            {label}
                                        </span>
                                        <span className="font-bold text-gray-900">{pct}%</span>
                                    </div>
                                    <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-gray-100">
                                        <div
                                            className="h-full rounded-full bg-indigo-500"
                                            style={{ width: `${pct}%` }}
                                        />
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Top performing blogs */}
                <div className="mt-6 rounded-2xl border border-gray-200 bg-white p-6">
                    <div className="flex items-center justify-between">
                        <h2 className="text-lg font-bold text-gray-900">Top Performing Blogs</h2>
                        <button
                            type="button"
                            className="inline-flex items-center gap-1 text-sm font-semibold text-indigo-600 hover:text-indigo-500"
                        >
                            View All
                            <ArrowRight className="h-4 w-4" />
                        </button>
                    </div>

                    <div className="mt-4 overflow-x-auto">
                        <table className="w-full min-w-[640px] border-collapse text-left">
                            <thead>
                                <tr className="border-b border-gray-100 text-xs font-semibold uppercase tracking-wide text-gray-400">
                                    <th className="pb-3 pr-4">Title</th>
                                    <th className="pb-3 pr-4">Slug</th>
                                    <th className="pb-3 pr-4 text-right">Views</th>
                                    <th className="pb-3 text-right">Created Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                {loading &&
                                    Array.from({ length: 4 }).map((_, i) => (
                                        <tr key={i} className="border-b border-gray-50 last:border-0">
                                            <td className="py-4 pr-4" colSpan={4}>
                                                <div className="h-6 w-full animate-pulse rounded bg-gray-100" />
                                            </td>
                                        </tr>
                                    ))}

                                {!loading && topBlogs.length === 0 && (
                                    <tr>
                                        <td colSpan={4} className="py-8 text-center text-sm text-gray-400">
                                            No published blogs yet.
                                        </td>
                                    </tr>
                                )}

                                {!loading &&
                                    topBlogs.map((blog) => (
                                        <tr
                                            key={blog.slug}
                                            className="border-b border-gray-50 last:border-0 hover:bg-gray-50/60"
                                        >
                                            <td className="py-4 pr-4">
                                                <div className="flex items-center gap-3">
                                                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-indigo-50">
                                                        <ImageIcon className="h-4 w-4 text-indigo-500" />
                                                    </div>
                                                    <div>
                                                        <p className="font-semibold text-gray-900">{blog.title}</p>
                                                        {blog.category && (
                                                            <p className="text-xs text-gray-400">{blog.category}</p>
                                                        )}
                                                    </div>
                                                </div>
                                            </td>
                                            <td className="py-4 pr-4 text-sm text-gray-500">/{blog.slug}</td>
                                            <td className="py-4 pr-4 text-right text-sm font-bold text-gray-900">
                                                {Number(blog.views ?? 0).toLocaleString()}
                                            </td>
                                            <td className="py-4 text-right text-sm text-gray-500">
                                                {formatDate(blog.createdAt)}
                                            </td>
                                        </tr>
                                    ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
}