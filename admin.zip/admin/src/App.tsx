import { BrowserRouter, Routes, Route } from 'react-router-dom'
import SignIn from '@/pages/auth/SignIn'
import { useEffect } from 'react'
import AdminAccessDenied from '@/pages/error/AdminAccessDenied'
import Dashboard from '@/pages/dashboard/Dashboard'
import { useAuthStore } from '@/store/authStore'
import VerifyToken from '@/components/token/VerifyToken'
import { apiClient } from '@/api/api-client'
import AdminPanelLayout from '@/components/layout/AdminPanelLayout'

const App = () => {
  useEffect(() => {
    const getAccessToken = async () => {
      try {
        const response = await apiClient.get("/user/get-access-token");
        const accessToken = response.data.accessToken;
        useAuthStore.getState().setAccessToken(accessToken);
      } catch (error) {
        console.error("Failed to get access token", error);
      }
    };
    getAccessToken();
  }, []);

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<SignIn />} />
        <Route path="/auth/login" element={<AdminAccessDenied />} />
        <Route path="/verify-token" element={<VerifyToken />} />
        <Route
          path="/dashboard"
          element={
            <AdminPanelLayout>
              <Dashboard />
            </AdminPanelLayout>
          }
        />
      </Routes>
    </BrowserRouter>
  );
};

export default App;